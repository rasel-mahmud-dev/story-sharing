<p align="center"><a href="https://qoddi.com"><img align="center" style="width:320px" src="https://devcenter.qoddi.com/wp-content/uploads/2021/11/800px-transparent-logo.png"/></a></p><br/>

# NodeJs Getting started

This repository can be built on [Qoddi](https://qoddi.com) as an example app.

More informations about NodeJS support on Qoddi can be <a href="https://devcenter.qoddi.com/node-js/">found here</a>

[comment]: <> ("node": "16.12.0")

