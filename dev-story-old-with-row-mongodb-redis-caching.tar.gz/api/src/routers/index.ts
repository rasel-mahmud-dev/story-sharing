
import postRoutes from "./postRoutes"
import authRoutes from "./authRoutes";
import filesRoutes from "./filesRoutes";
import appAdminRoutes from "./appAdminRoutes";
import androidRouter from "./androidRouter";

function routes (app){
  app.get("/", (req, res)=>{
    res.send("Hello")
  })
  postRoutes(app)
  authRoutes(app)
  filesRoutes(app)
  appAdminRoutes(app)
  androidRouter(app)
}

module.exports = routes
export default routes
