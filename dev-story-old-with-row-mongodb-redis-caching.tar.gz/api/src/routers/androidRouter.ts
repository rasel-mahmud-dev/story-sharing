
import getAuthID from "../middlewares/getAuthID"
import controller from "../controllers"

const androidRouter = (app)=>{
  
  app.get("/api/android/posts", controller.androidAppController.getPosts);
  
  app.get("/api/android/posts/:post_id", controller.androidAppController.getPost)
  
  
  app.post("/api/android/post/add-post", getAuthID, controller.androidAppController.addPost)
  app.post("/api/android/post/update-post", getAuthID, controller.androidAppController.updatePost)
  
  
  app.post("/api/android/posts/delete", getAuthID, controller.postController.deletePost)
  app.get("/api/android/post/:slug", controller.postController.getPost)
  
  
  app.post("/api/android/markdown/content", controller.postController.getPostContent)
  
  // body => { path: string }
  app.post("/api/android/raw-md-content", controller.postController.getRawMarkdownContent)

  
  app.post("/api/android/file-content", controller.postController.getFileContent)
  app.get("/api/android/download-md", controller.androidAppController.downloadMarkdownFiles)
  
}


export default androidRouter
