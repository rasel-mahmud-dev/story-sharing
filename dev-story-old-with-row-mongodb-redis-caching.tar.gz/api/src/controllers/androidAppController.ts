import {writeFile} from "fs/promises";
import path from "path";
import response from "../response";
import {readdir, stat, rm} from "fs/promises";
import saveLog from "../logger/saveLog";

import {ObjectId} from "mongodb";
import { setUsersPostsIntoCache} from "../redisCacheActions/usersPosts";

import AndroidPost from "../models/AndroidPost";
import slugify from "slugify";
import User from "../models/User";
import {setAdminPostsIntoCache} from "../redisCacheActions/adminPosts";
import errorConsole from "../logger/errorConsole";
import uploadMarkdownFile from "../utilities/uploadMarkdownFile";

const shortid = require("shortid")

export const getPosts = (req, res, next) =>{
  (async function (){
    
    const  { author_id } = req.query
    let client;
    try {
  
      let posts = await AndroidPost.find()
      res.send(posts)
      return
      
      /** get users posts from redis cache using author id */
      if(author_id){
          let p: any = await AndroidPost.aggregate([
            { $match:  author_id ? { author_id: new ObjectId(author_id) } : {} },
            { $lookup: {
                from: "users",
                localField: "author_id",
                foreignField: "_id",
                as: "author"
              }},
            { $unwind: { path: "$author", preserveNullAndEmptyArrays: true } },
            { $project: { author: { password: 0, created_at: 0, updated_at: 0, description: 0} } }
          ])
          
          /// make cache admin posts
          // let admin: any = await User.findOne({_id: new ObjectId(author_id), role: "admin"}, {})
          // if(admin){
          //   await pushAdminPostsIntoRedisCache("admin_posts", admin._id, p)
          // }
          
          
        }
      
    } catch (ex){
      
      // response(res, 500, ex.message || "Internal Error")
    } finally {
      client?.quit()
    }
    
  }())
  
  
  // let client;
  // try {
  //
  //   client = await redisConnect()
  //
  //   let posts = []
  //   if (author_id) {
  //     // posts = db.get('posts').filter({author_id: author_id}).value()
  //     let allPosts = await getHashData('posts', client)
  //     if(allPosts) {
  //       posts = allPosts.filter(p => p.author_id === author_id)
  //     }
  //   } else {
  //     posts = await getHashData('posts', client)
  //   }
  //
  //   let users = await getHashData("users", client)
  //
  //   let posts_with_user = []
  //   // usersSync(users, client)
  //
  //
  //   posts && posts.length > 0 && posts.forEach(post => {
  //     let user = users.find(u => u.id === post.author_id)
  //     if (user) {
  //       posts_with_user.push({
  //         ...post,
  //         author: {
  //           username: user.first_name + " " + user.last_name,
  //           avatar: user.avatar
  //         }
  //       })
  //     } else {
  //       posts_with_user.push({
  //         ...post,
  //         author: {}
  //       })
  //     }
  //   })
  //
  //   response(res, 200, {posts: posts_with_user})
  //
  // } catch (ex){
  //   errorConsole(ex)
  //   response(res, 500, "Server Error. Please Try Again")
  // } finally {
  //   client?.quit()
  // }
  
}


export const addPost = async (req, res, next) =>{
  
  let user_id = req.user_id
  let { title, cover = "", author_id, mdContent, tags, summary = "" } = req.body
  
  if(!(title && author_id && mdContent)){
    return response(res, 500, "incomplete post data")
  }
  if(user_id !== author_id){
    return response(res, 401, {message: "unauthorized" })
  }
  
  
  let client;
  try {
    let slug = slugify(title, {
      replacement: "-",
      strict: true,
      lower: true,
      trim: true
    })
    
    if (!slug) {
      slug = shortid.generate()
    }
  
  
  
  
    let mdFilePath = `app_markdown/${slug}.md`
    if(mdContent) {
      // let isUploaded = await updateFile(mdContent, mdFilePath)
  
      mdFilePath = await uploadMarkdownFile(mdFilePath, mdContent)
  
      if (!mdFilePath) {
        saveLog("app_markdown file create fail " + mdFilePath)
        return response(res, 409, {message: "app_markdown file create fail"})
      }
    }
    
    let newPost: any = {
      author_id: new ObjectId(author_id),
      slug,
      title,
      cover,
      tags: tags,
      summary,
      path: mdContent ? mdFilePath : "",
      created_at: new Date()
    }
    
    let n = new AndroidPost({
      ...newPost,
    })
    

    let r: any = await n.save(true)
    
    if(!r){
      response(res, 409, "post create fail")
      return
    }
    
    // populated author...
    let user: any = await User.findOne({_id: new ObjectId(author_id)}, {})
    
    if(user){
      let { password, ...other } = user
      r.author = {
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
        avatar: user.avatar
      }
      response(res, 200, {post: r})
      
    } else {
      response(res, 200, {post: r})
    }
    
  } catch (ex){
    errorConsole(ex)
    saveLog(ex.message ? ex.message : "post create fail")
    response(res, 409, "post create fail")

  } finally {
    client?.close()
  }
  
}

export const updatePost = async (req, res, next) =>{
  
  let user_id = req.user_id
  if(!user_id){
    return response(res, 409, "Unauthorized")
  }
  
  
  let { _id, title, cover, summary, mdContent, tags } = req.body
  
  let client;
  
  try {
    
    let post: any  = await AndroidPost.findOne({_id: new ObjectId(_id)}, {})
    if(post) {
      if (title) {
        post.title = title
      }
      if(summary){
        post.summary = summary
      }
      if (tags) {
        post.tags = tags
      }
      if (cover) {
        post.cover = cover
      }
      if (!post.created_at) {
        post.created_at = new Date()
      }
      
      try {
     
        if(mdContent) {
          await writeFile(post.path, mdContent)
        }
        
        let isUpdated = await AndroidPost.update(
          {_id: new ObjectId(post._id)},
          {$set: post}
        )
        
        if (isUpdated) {
          response(res, 200, {post: post})
        } else {
          response(res, 500, "post update fail 1")
          saveLog("Internal Error. Please Try Again", req.url, req.method)
        }
      
        
      } catch (ex){
        response(res, 500, "post update fail")
        saveLog(ex.message ? ex.message : "Internal Error. Please Try Again", req.url, req.method)
      }
      
      
    } else {
      response(res, 404, "post Not found")
    }
    
    
  } catch (ex){
    errorConsole(ex)
    saveLog(ex.message ? ex.message : "Internal Error. Please Try Again", req.url, req.method)
    response(res, 500, "Internal Error. Please Try Again")
    
  } finally {
    client?.close()
  }
}

export const getPost = async (req, res, next) =>{
  let { post_id } = req.params
  let client;
  try {
    let posts: any = [];
    if(!post_id) {
      return response(res, 404, "post not found")
    }
    
    posts =  await AndroidPost.aggregate([
      { $match: {_id: new ObjectId(post_id)}},
      { $lookup: {
          from: "users",
          localField: "author_id",
          foreignField: "_id",
          as: "author"
        }},
      { $unwind: { path: "$author", preserveNullAndEmptyArrays: true } }
    ])
    
    //   .then(d=>{
    //   console.log(d)
    // })
    
    if (posts.length > 0) {
      response(res, 200, {
        post: {
          ...posts[0]
        }
      })
      
    } else {
      saveLog("post not found with id: " + post_id)
      response(res, 404, "post not found")
    }
    
  } catch (ex){
    errorConsole(ex)
    saveLog(ex.message ? ex.message : "internal error")
    response(res, 500, ex.message)
  } finally {
    client?.close()
  }
  
}

export const downloadMarkdownFiles  = async (req, res, next) => {
  const mdPath = path.resolve("app_markdown")
  let archiver = require("archiver")
  
  const archive = archiver('zip', {
    zlib: { level: 9 } // Sets the compression level.
  });
  
  archive.pipe(res);
  archive.directory(mdPath, false)
  archive.finalize();
  
  
  let files = await readdir(mdPath)
  // files.forEach((file, i)=>{
  //   archive.file(mdPath + "/" +file, { name: file })
  //   if((i + 1) === files.length){
  //     archive.finalize();
  //     // stream.close()
  //   }
  // })
}

