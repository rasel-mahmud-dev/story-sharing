import * as allPosts from "./allPosts"
import * as adminPosts from "./adminPosts"
import * as usersPosts from "./usersPosts"

export  default { allPosts,
  adminPosts,
  usersPosts  }