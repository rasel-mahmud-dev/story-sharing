import React from "react";

const LoginStateContext = React.createContext({})

export default LoginStateContext