import React from "react";

const DashboardContext = React.createContext({})

export default DashboardContext